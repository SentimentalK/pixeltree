# Changelog

- 2026-11: first entry
