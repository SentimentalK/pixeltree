# Welcome

This vault has three notes. See [[Projects]] and [[Reading list]].

Visit the harbor office on 2026-11-20.