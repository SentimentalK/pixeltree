Low tide at 06:40
High tide at 19:05