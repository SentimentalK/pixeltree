# Welcome

This vault has three notes. See [[Projects]] and [[Reading list]].
